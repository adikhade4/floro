<?php /* /home/adityakhade/Music/Q3/floroapp/resources/views//home.blade.php */ ?>
<?php $__env->startSection('content'); ?>
 <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div>
                            <span class="float-sm-left h5">
                                User Management
                            </span>
                            
                             <div class="my-4">
                                <form action="/search" method="GET">
                                <div class="input-group">
                                <input class="form-control mr-sm-4" type="search" placeholder="Search by User Name,Email" name="search" aria-label="Search">
                                <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                                </form>
                             </div>
                             
                            <a class="btn btn-primary mt-2 float-sm-right" style="margin-left: 10px;" href="/create" >
                                Create User Account
                            </a>
                            

                            <a class="btn btn-primary mt-2 float-sm-right" href="/export" >
                                Export Users
                            </a>
                        </div>
                    </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                      <form action="/sort" method="GET">
                <div class="table-list-container table-responsive">
                
                    <table class="table table-striped table-hover">

                <div class="search-bar col-sm-12 col-lg-6">
                   <thead class="table-head">
                   
                    <tr>
                    <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('username'));?></th>
                    <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('firstname'));?></th>
                    <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('lastname'));?></th>
                    <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('email'));?></th>
                    <th scope="col">Created at</th>
                    <th scope="col">Last Login at</th>
                    
                    <th scope="col">Actions</th>
                    </tr>
                 
                  </thead>
                    
                     <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                   <tbody>
                  
                        <tr>
                       
                        <td><?php echo e($userm->username); ?></td>
                        <td><?php echo e($userm->firstname); ?></td>
                        <td><?php echo e($userm->lastname); ?></td>
                        <td><?php echo e($userm->email); ?></td>
                        <td><?php echo e($userm->created_at); ?></td>
                        <td><?php echo e($userm->updated_at); ?></td>
                        <td> 
                        <a href="/user/<?php echo e($userm->id); ?>/edit" class="btn btn-primary">Edit</a>
                        <a href="/user/<?php echo e($userm->id); ?>" class="btn btn-danger">Delete</a>
                        </tr>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <?php echo e($user->links()); ?>

                </div>
                </form>
               </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>