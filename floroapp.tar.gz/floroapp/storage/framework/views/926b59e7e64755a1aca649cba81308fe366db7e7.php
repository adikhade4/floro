<?php /* /home/adityakhade/floroapp/resources/views/edit.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Register')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('UserName')); ?><span class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?><span class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?><span class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?><span class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="form-group row justify-content-md-center">
                                <label for="firstname" class="col-md-2 col-form-label ">First Name <span class="text-danger">*</span></label>

                                <div class="col-md-4">
                                    <input id="firstname" type="text" class="form-control" name="firstname" value="" required autofocus>

                                                                    </div>
                            </div>

                            <div class="form-group row justify-content-md-center">
                                <label for="lastname" class="col-md-2 col-form-label ">Last Name <span class="text-danger">*</span></label>

                                <div class="col-md-4">
                                    <input id="lastname" type="text" class="form-control" name="lastname" value="" required autofocus>

                                                                    </div>
                            </div>

                            <div class="form-group row justify-content-md-center">
                                <label for="address" class="col-md-2 col-form-label ">Address <span class="text-danger">*</span></label>

                                <div class="col-md-4">
                                    <textarea rows="2" cols="50" class="form-control" name="address" required autofocus> </textarea>

                                                                    </div>
                            </div>

                            <div class="form-group row justify-content-md-center">
                                <label for="houseno" class="col-md-2 col-form-label ">House Number <span class="text-danger">*</span></label>

                                <div class="col-md-4">
                                    <input id="houseno" type="text" class="form-control" name="houseno" value="" required autofocus>

                                                                    </div>
                            </div>

                            <div class="form-group row justify-content-md-center">
                                <label for="postalcode" class="col-md-2 col-form-label ">Postal Code <span class="text-danger">*</span></label>

                                <div class="col-md-4">
                                    <input id="postalcode" type="text" class="form-control" name="postalcode" value="" required autofocus>

                                                                    </div>
                            </div>

                            <div class="form-group row justify-content-md-center">
                                <label for="city" class="col-md-2 col-form-label ">City <span class="text-danger">*</span></label>

                                <div class="col-md-4">
                                    <input id="city" type="text" class="form-control" name="city" value="" required autofocus>

                                                                    </div>
                            </div>

                            <div class="form-group row justify-content-md-center">
                                <label for="telephoneno" class="col-md-2 col-form-label ">Telephone number <span class="text-danger">*</span></label>

                                <div class="col-md-4">
                                    <input id="telephoneno" type="text" class="form-control" name="telephoneno" value="" required autofocus>

                                                                    </div>
                            </div>

                            <div class="form-group row justify-content-md-center">
                                <label for="is_active" class="col-md-2 col-form-label ">Activate User <span class="text-danger">*</span></label>

                                <div class="col-md-4 checkbox-field">

                                    <input id="is_active" type="checkbox" class="form-control" name="is_active" value="1"  checked>

                                                                    </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-4 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        Save
                                    </button>

                                    <button type="button" class="btn btn-primary" onClick="resetFormFields();">
                                        Reset
                                    </button>

                                </div>

                        
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>