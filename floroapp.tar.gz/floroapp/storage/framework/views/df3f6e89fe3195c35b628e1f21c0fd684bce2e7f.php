<?php /* /home/adityakhade/floroapp/resources/views//create.blade.php */ ?>
<?php $__env->startSection('content'); ?>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-8">
                            <div class="card">
                                <div class="card-header"><?php echo e(__('Register')); ?></div>

                                <div class="card-body">
                                <?php if($errors->any()): ?>
                <div class="notification is-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                </div>
                <?php endif; ?>
                    <form id="myForm" method="POST" action="/home">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row <?php echo e($errors->has('username') ? 'has-error' : ''); ?>">
                            <label for="username" class="col-md-4 col-form-label text-md-right"><?php echo e(__('UserName')); ?><span class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input id="username" type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" autofocus>

                                <?php if($errors->has('username')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('username')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                         <div class="form-group row <?php echo e($errors->has('firstname') ? 'has-error' : ''); ?>">
                            <label for="firstname" class="col-md-4 col-form-label text-md-right"><?php echo e(__('FirstName')); ?><span class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input id="firstname" type="text" class="form-control" name="firstname" value="<?php echo e(old('firstname')); ?>">

                                <?php if($errors->has('firstname')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('firstname')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                       <div class="form-group row <?php echo e($errors->has('lastname') ? 'has-error' : ''); ?>">
                            <label for="lastname" class="col-md-4 col-form-label text-md-right"><?php echo e(__('LastName')); ?><span class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input id="lastname" type="text" class="form-control" name="lastname" value="<?php echo e(old('lastname')); ?>" >

                                <?php if($errors->has('lastname')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('lastname')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
                            <label for="address" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Address')); ?><span class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input id="address" type="text" class="form-control" name="address" value="<?php echo e(old('address')); ?>">
                                <?php if($errors->has('address')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('address')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                         <div class="form-group row <?php echo e($errors->has('city') ? 'has-error' : ''); ?>">
                            <label for="city" class="col-md-4 col-form-label text-md-right"><?php echo e(__('City')); ?><span class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input id="city" type="text" class="form-control" name="city" value="<?php echo e(old('city')); ?>">
                                <?php if($errors->has('city')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('city')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                         <div class="form-group row <?php echo e($errors->has('houseno') ? 'has-error' : ''); ?>">
                            <label for="houseno" class="col-md-4 col-form-label text-md-right"><?php echo e(__('HouseNumber')); ?><span class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input id="houseno" type="text" class="form-control" name="houseno" value="<?php echo e(old('houseno')); ?>">
                                <?php if($errors->has('houseno')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('houseno')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                     <div class="form-group row <?php echo e($errors->has('postalcode') ? 'has-error' : ''); ?>">
                            <label for="postalcode" class="col-md-4 col-form-label text-md-right"><?php echo e(__('PostalCode')); ?><span class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input id="postalcode" type="text" class="form-control" name="postalcode" value="<?php echo e(old('postalcode')); ?>">
                                <?php if($errors->has('postalcode')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('postalcode')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>     
                          <div class="form-group row <?php echo e($errors->has('telephoneno') ? 'has-error' : ''); ?>">
                            <label for="telephoneno" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Telephone number')); ?><span class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input id="telephoneno" type="text" class="form-control" name="telephoneno" value="<?php echo e(old('telephoneno')); ?>">
                                <?php if($errors->has('telephoneno')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('telephoneno')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>       
                        <div class="form-group row <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?><span class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" value="<?php echo e(old('email')); ?>" name="email">

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?><span class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password">

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row <?php echo e($errors->has('password_confirmation') ? 'has-error' : ''); ?>">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?><span class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation">
                                 <?php if($errors->has('password_confirmation')): ?>
                <span class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
            <?php endif; ?>
                            </div>
                        </div>
                         <div class="form-group row ">
                                <label for="status" class="col-md-4 col-form-label text-md-right">Activate User <span class="text-danger">*</span></label>

                                <div class="col-md-6 checkbox-field">

                                    <input id="status" type="checkbox" class="form-control" name="status" value="1">

                                 </div>
                            </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('CreateAccount')); ?>

                                </button>
                                  <button type="button" class="btn btn-primary" onClick="resetFormFields();">
                                        Reset
                                    </button>
                            </div>
                        </div>
                    </form>
                
                    <script>
                    function resetFormFields() {
                    /*Put all the data posting code here*/
                    document.getElementById("myForm").reset();
                    }
                    </script>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>