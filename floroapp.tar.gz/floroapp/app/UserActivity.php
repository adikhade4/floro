<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
// use App\User;
class UserActivity extends Model
{
    protected $table = "useractivity";
    
    protected $fillable = [
        'id', 
        'user_id',
        'old_value',
        'new_value',
        'field_name',
        'modified_by'
       
   ];
  





    public function users()
    {
       return $this->belongsTo(User::class);
    }
}
